<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('faktur_model');
	}

	public function debit(){
		if ($this->session->userdata('user_masuk')) {
			$data['user'] = $this->session->userdata('user_masuk');
			$data['posisi'] = 'Debit Pajak Masukkan';
			if ($this->session->flashdata('gagalDebit')) {
				$data['gagalDebit'] = $this->session->flashdata('gagalDebit');
			}
			if ($this->session->flashdata('sukses')) {
				$data['sukses'] = $this->session->flashdata('sukses');
			}

			$this->load->view('user-input-debit',$data);			
		}
		else
			redirect('home');
	}

	public function kredit(){
		if ($this->session->userdata('user_masuk')) {
			$data['user'] = $this->session->userdata('user_masuk');
			$data['posisi'] = 'Kredit Pajak Masukkan';
			if ($this->session->flashdata('gagalDebit')) {
				$data['gagalDebit'] = $this->session->flashdata('gagalDebit');
			}
			if ($this->session->flashdata('sukses')) {
				$data['sukses'] = $this->session->flashdata('sukses');
			}

			$this->load->view('user-input-kredit',$data);			
		}
		else
			redirect('home');
	}	

	public function rekonsiliasi(){
		if ($this->session->userdata('user_masuk')) {
			$data['user'] = $this->session->userdata('user_masuk');
			$data['posisi'] = 'Rekonsiliasi';

			if (!is_null($this->faktur_model->getTotalPpnDebit())) {
				$data['ppnDebit'] = $this->faktur_model->getTotalPpnDebit()->result_array()[0]['total_ppn'];
			}
			else
				$data['ppnDebit'] = 0;			
			
			if (!is_null($this->faktur_model->getTotalPpnKredit())) {
				$data['ppnKredit'] = $this->faktur_model->getTotalPpnKredit()->result_array()[0]['total_ppn'];
			}
			else
				$data['ppnKredit'] = 0;

			$data['selisihPpn'] = ($data['ppnDebit'] - $data['ppnKredit']);
			if ($data['selisihPpn'] < 0) {
				$data['selisihPpn'] *= -1;
			}
			// fixed
			
			if (!empty($this->faktur_model->matchingFaktur())) {
				$noFakturs = $this->faktur_model->matchingFaktur()->result();
				foreach ($noFakturs as $noFaktur) {
					$this->faktur_model->updateMatchingFaktur($noFaktur->NO_FAKTUR);
				}
			}

			// fixed

			$kredit = $this->faktur_model->getUnmatchedKredit();
			$debit = $this->faktur_model->getUnmatchedDebit();

			if (!is_null($this->faktur_model->ppnUnmatchedKredit())) {
				$data['ppnUnKredit'] = $this->faktur_model->ppnUnmatchedKredit()->result_array()[0]['total_ppn'];
			}
			else
				$data['ppnUnKredit'] = 0;

			if (!is_null($this->faktur_model->ppnUnmatchedDebit())) {
				$data['ppnUnDebit']= $this->faktur_model->ppnUnmatchedDebit()->result_array()[0]['total_ppn'];
			}
			else
				$data['ppnUnDebit'] = 0;

			$data['kontrolRekon'] = ($data['ppnUnDebit'] - $data['ppnUnKredit']);
			if ($data['kontrolRekon'] < 0) {
				$data['kontrolRekon'] *= -1;
			}
			// fixed
			if (!empty($kredit)) {
				$data['totalKredit'] = count($kredit->result_array());
				$data['fakturKredit'] = $kredit->result();
			}
			else
				$data['totalKredit'] = 0;

			if (!empty($debit)) {
				$data['totalDebit'] = count($debit->result_array());
				$data['fakturDebit'] = $debit->result();
			}
			else
				$data['totalDebit'] = 0;
			

			$this->load->view('rekonsiliasi',$data);			
		}
		else
			redirect('home');
	}

}
