<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
    } 
	public function index()
	{
		if ($this->session->flashdata('pesan') == 'gagal' ) {
			$data['pesan'] = "gagal";
			$this->load->view('form_login',$data);
		}
		else
			$this->load->view('form_login');
	}

	public function login(){
		$username = $this->input->post('username');
		$pwd = $this->input->post('pwd');

		$result = $this->user_model->cek_user($username,$pwd);
		if (is_array($result)) {
			foreach ($result as $key) {
				$array = array(
					'id' => $key->id_user,
					'username'=> $key->username,
					'nama' => $key->nama_user,
					'level' => $key->level
				);
				
				$this->session->set_userdata('user_masuk',$array);	
			}
			redirect('home/dashboard');
		}
		else{
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('home');
		}

	}

	public function dashboard(){
		if ($this->session->userdata('user_masuk')) {
			$data['user'] = $this->session->userdata('user_masuk');
			$data['posisi'] = 'dashboard';

			if ($this->session->flashdata('pesan') == 'berhasil' ) {
				$data['pesan'] = "Faktur tersimpan";
			}
			$this->load->view('dashboard',$data);			
		}
		else
			redirect('home');
		
	}

	public function logout(){
		if ($this->session->userdata('user_masuk')) {
			$this->session->sess_destroy();
		}
		redirect('home');
	}

}
