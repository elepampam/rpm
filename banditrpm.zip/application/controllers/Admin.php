<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('faktur_model');
	}

	public function debit(){
		if ($this->session->userdata('user_masuk')) {
			$data['user'] = $this->session->userdata('user_masuk');
			$data['posisi'] = 'Debit Pajak Masukkan';
			if ($this->session->flashdata('gagalDebit')) {
				$data['gagalDebit'] = $this->session->flashdata('gagalDebit');
			}
			if ($this->session->flashdata('sukses')) {
				$data['sukses'] = $this->session->flashdata('sukses');
			}

			$this->load->view('admin-input-debit',$data);			
		}
		else
			redirect('home');
	}

	public function kredit(){
		if ($this->session->userdata('user_masuk')) {
			$data['user'] = $this->session->userdata('user_masuk');
			$data['posisi'] = 'Kredit Pajak Masukkan';
			if ($this->session->flashdata('gagalDebit')) {
				$data['gagalDebit'] = $this->session->flashdata('gagalDebit');
			}
			if ($this->session->flashdata('sukses')) {
				$data['sukses'] = $this->session->flashdata('sukses');
			}

			$this->load->view('admin-input-kredit',$data);			
		}
		else
			redirect('home');
	}	

	public function rekonsiliasi(){
		if ($this->session->userdata('user_masuk')) {
			$data['user'] = $this->session->userdata('user_masuk');
			$data['posisi'] = 'Rekonsiliasi';

			$data['ppnDebit'] = $this->faktur_model->getTotalPpnDebit()->result_array()[0]['total_ppn'];
			$data['ppnKredit'] = $this->faktur_model->getTotalPpnKredit()->result_array()[0]['total_ppn'];
			$data['selisihPpn'] = ($data['ppnDebit'] - $data['ppnKredit']) * -1;

			$noFakturs = $this->faktur_model->matchingFaktur()->result();
			if (!empty($noFakturs)) {
				foreach ($noFakturs as $noFaktur) {
					$this->faktur_model->updateMatchingFaktur($noFaktur->NO_FAKTUR);
				}
			}
			$kredit = $this->faktur_model->getUnmatchedKredit();
			$debit = $this->faktur_model->getUnmatchedDebit();

			$data['totalKredit'] = count($kredit->result_array());
			$data['ppnUnKredit'] = $this->faktur_model->ppnUnmatchedKredit()->result_array()[0]['total_ppn'];
			$data['totalDebit'] = count($debit->result_array());
			$data['ppnUnDebit'] = $this->faktur_model->ppnUnmatchedDebit()->result_array()[0]['total_ppn'];
			$data['kontrolRekon'] = ($data['ppnUnDebit'] - $data['ppnUnKredit']) * -1;
			$data['fakturKredit'] = $kredit->result();
			$data['fakturDebit'] = $debit->result();

			$this->load->view('rekonsiliasi',$data);			
		}
		else
			redirect('home');
	}

}
