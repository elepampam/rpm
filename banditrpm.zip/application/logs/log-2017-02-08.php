<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-08 20:39:16 --> Config Class Initialized
INFO - 2017-02-08 20:39:16 --> Hooks Class Initialized
DEBUG - 2017-02-08 20:39:16 --> UTF-8 Support Enabled
INFO - 2017-02-08 20:39:16 --> Utf8 Class Initialized
INFO - 2017-02-08 20:39:16 --> URI Class Initialized
INFO - 2017-02-08 20:39:16 --> Router Class Initialized
INFO - 2017-02-08 20:39:16 --> Output Class Initialized
INFO - 2017-02-08 20:39:16 --> Security Class Initialized
DEBUG - 2017-02-08 20:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 20:39:16 --> Input Class Initialized
INFO - 2017-02-08 20:39:16 --> Language Class Initialized
INFO - 2017-02-08 20:39:16 --> Loader Class Initialized
INFO - 2017-02-08 20:39:16 --> Helper loaded: url_helper
INFO - 2017-02-08 20:39:16 --> Helper loaded: form_helper
INFO - 2017-02-08 20:39:16 --> Database Driver Class Initialized
INFO - 2017-02-08 20:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 20:39:16 --> Controller Class Initialized
INFO - 2017-02-08 20:39:16 --> Model Class Initialized
INFO - 2017-02-08 20:39:16 --> Model Class Initialized
ERROR - 2017-02-08 20:39:16 --> Severity: Notice --> Undefined index: temp C:\xampp\htdocs\banditrpm\application\controllers\User.php 52
INFO - 2017-02-08 20:39:16 --> File loaded: C:\xampp\htdocs\banditrpm\application\views\rekonsiliasi.php
INFO - 2017-02-08 20:39:16 --> Final output sent to browser
DEBUG - 2017-02-08 20:39:16 --> Total execution time: 0.2076
