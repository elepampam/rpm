<?php 
class Faktur{

	public function __construct(){
		parent::__construct();
        $this->load->model('faktur_model');
	}

	private function csvtoarray($filecsv){
		$filecsv = fopen($filecsv, 'r');
		 while (!feof($filecsv) ) {
	        $array[] = fgetcsv($filecsv, 1024);
	    }
	    fclose($filecsv);
		return $array;
	}

	public function inputdebit(){
		if ($this->session->userdata('user_masuk')) {
			$config['upload_path'] = './file_csv/debit/';
			$config['allowed_types'] = 'csv';
			$this->load->library('upload', $config);

			$data['user'] = $this->session->userdata('user_masuk');

			if (!$this->upload->do_upload('file-csv')){
				$error = array('error' => $this->upload->display_errors());
				$tes['data'] = $error;
				$this->load->view('kosongan',$tes);
			}else{
				$succes = $this->upload->data();
				$fakturs = $this->csvtoarray($succes['full_path']);
				array_shift($fakturs);
				for ($i=0; $i < count($fakturs); $i++) { 
					if (!empty($fakturs[$i])) {
						$date = explode('/', $fakturs[$i][6]);
						$temp = $date[0];
						$date[0] = $date[2];
						$date[2] = $temp;
						$faktur = array(
							'NO_FAKTUR' => $fakturs[$i][1].$fakturs[$i][2].$fakturs[$i][3],
							'FM' => $fakturs[$i][0],
							'KD_JENIS' => $fakturs[$i][1],
							'FG_PENGGANTI' => $fakturs[$i][2],
							'NOMOR_FAKTUR' => $fakturs[$i][3],
							'MASA_PAJAK' => $fakturs[$i][4],
							'TAHUN_PAJAK' => $fakturs[$i][5],
							'TANGGAL_FAKTUR' => implode('-', $date),
							'NPWP' => $fakturs[$i][7],
							'NAMA' => $fakturs[$i][8],
							'ALAMAT_LENGKAP' => $fakturs[$i][9],
							'JUMLAH_DPP' => $fakturs[$i][10],
							'JUMLAH_PPN' => $fakturs[$i][11],
							'JUMLAH_PPNBM' => $fakturs[$i][12],
							'IS_CREDITABLE' => $fakturs[$i][13],
							'USER_INPUT' => 1
							 );
						if (!$this->faktur_model->inputFakturDebit($faktur)) {
							$gagalDebit[] = $faktur;
						}							
					}
					
				}
				if (isset($gagalDebit)) {
					$data['gagalDebit'] = $gagalDebit;
				}
				else
					$data['pesan'] = 'faktur berhasil dimasukkan';
				
				// $this->load->view('kosongan', $data);
				redirect('home/dashboard');
				$this->load->view('dashboard', $data);
			}
		}
		else
			redirect('home');
	}
	public function inputkredit(){
		if ($this->session->userdata('user_masuk')) {
			$config['upload_path'] = './file_csv/kredit/';
			$config['allowed_types'] = 'csv';
			$this->load->library('upload', $config);

			$data['user'] = $this->session->userdata('user_masuk');

			if (!$this->upload->do_upload('file-csv')){
				$error = array('error' => $this->upload->display_errors());
				$tes['data'] = $error;
				$this->load->view('kosongan',$tes);
			}else{
				$succes = $this->upload->data();
				$fakturs = $this->csvtoarray($succes['full_path']);
				array_shift($fakturs);
				for ($i=0; $i < count($fakturs); $i++) { 
					if (!empty($fakturs[$i])) {
						$date = explode('/', $fakturs[$i][6]);
						$temp = $date[0];
						$date[0] = $date[2];
						$date[2] = $temp;
						$faktur = array(
							'NO_FAKTUR' => $fakturs[$i][1].$fakturs[$i][2].$fakturs[$i][3],
							'FM' => $fakturs[$i][0],
							'KD_JENIS' => $fakturs[$i][1],
							'FG_PENGGANTI' => $fakturs[$i][2],
							'NOMOR_FAKTUR' => $fakturs[$i][3],
							'MASA_PAJAK' => $fakturs[$i][4],
							'TAHUN_PAJAK' => $fakturs[$i][5],
							'TANGGAL_FAKTUR' => implode('-', $date),
							'NPWP' => $fakturs[$i][7],
							'NAMA' => $fakturs[$i][8],
							'ALAMAT_LENGKAP' => $fakturs[$i][9],
							'JUMLAH_DPP' => $fakturs[$i][10],
							'JUMLAH_PPN' => $fakturs[$i][11],
							'JUMLAH_PPNBM' => $fakturs[$i][12],
							'IS_CREDITABLE' => $fakturs[$i][13],
							'BULAN_KREDIT' => $this->input->post('masa-bulan'),
							'TAHUN_KREDIT' => $this->input->post('masa-tahun'),
							'USER_INPUT' => 1
							 );
						if (!$this->faktur_model->inputFakturKredit($faktur)) {
							$gagalKredit[] = $faktur;
						}							
					}
					
				}
				if (isset($gagalKredit)) {
					$data['gagalKredit'] = $gagalKredit;
				}
				else{
					
					$data['pesan'] = 'faktur berhasil dimasukkan';
				}
				
				// $this->load->view('kosongan', $data);
				redirect('home/dashboard');
				$this->load->view('dashboard', $data);
			}
		}
		else
			redirect('home');
	} 
?>