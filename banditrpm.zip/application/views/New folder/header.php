<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>efaktur <?php if (isset($posisi)) {
	echo " | ".$posisi;
} ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendor/materialize/css/materialize.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendor/font-awesome/css/font-awesome.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/custom-navbar.css');?>">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendor/jquery-ui/jquery-ui.css');?>">
</head>
