<footer class="page-footer  indigo lighten-2">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">REKONSILIASI PAJAK MASUKAN V 1.0</h5>
          <p class="grey-text text-lighten-4">
            Merupakan aplikasi pendukung anda untuk merekam faktur pajak yang telah diakui sebagai pajak masukan dan melakukan pengkreditan pajak masukan tersebut sesuai masa pajak yang ditentukan. Hasilkan laporan-laporan rekonsiliasi yang berguna bagi anda untuk melakukan pembayaran PPN terutang dan pelaporan PPN masa. Aplikasi ini merupakan generasi pertama dari alat bantu rekonsiliasi pajak masukan dan hanya digunakan untuk administrasi pajak di ITDC.

          </p>


        </div>
        <div class="col l3 s12">
          <h5 class="white-text">Settings</h5>
          <ul>
            <li><a class="white-text" href="#!">Link 1</a></li>
            <li><a class="white-text" href="#!">Link 2</a></li>
            <li><a class="white-text" href="#!">Link 3</a></li>
            <li><a class="white-text" href="#!">Link 4</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Design by <span class="orange-text text-lighten-3">bandit akt</span> | <span class="orange-text text-lighten-3">eLepampam</span>
      </div>
    </div>
  </footer>