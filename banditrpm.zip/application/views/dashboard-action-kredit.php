<div class="col-md-7">
    <div class="row relative-box-right">
        <div class="absolute-box" style="top:135px">
            <div class="col-md-3 icon-box">
                <a href="<?php echo site_url(); ?>/user/kredit" class="icon">
                    <i class="fa fa-qrcode" aria-hidden="true"></i>
                    <p>Pengkredittan Pajak Masukkan</p>
                </a>
            </div>
            <div class="col-md-3 icon-box">
                <a href="<?php echo site_url(); ?>/user/rekonsiliasi" class="icon">
                    <i class="fa fa-files-o" aria-hidden="true"></i>
                    <p>Rekon</p>
                </a>
            </div>
            <div class="col-md-3 icon-box">
                <a href="" class="icon">
                    <i class="fa fa-search" aria-hidden="true"></i>
                    <p>Pencarian</p>
                </a>
            </div>
        </div>
    </div>
</div>
