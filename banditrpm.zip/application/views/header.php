<!DOCTYPE html>
<html>

<head>
    <title><?php echo $posisi; ?></title>
    <link href="<?=base_url();?>assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <script src="https://use.fontawesome.com/0f98046489.js"></script>
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/dashboardview.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/filepage.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/rekonpage.css">
</head>