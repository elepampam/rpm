<div class="user-action">
    <a class="circle-icon action" id="logout" href="<?php echo site_url();?>/home/logout">
        <i class="fa fa-sign-out" aria-hidden="true"></i>
    </a>
    <a class="circle-icon action" id="user-profile">
        <i class="fa fa-user" aria-hidden="true"></i>
    </a>
    <a class="circle-icon action" id="help">
        <i class="fa fa-question" aria-hidden="true"></i>
    </a>
    <div class="circle-icon" id="user">
        <img src="<?php echo base_url(); ?>assets/user_images/<?php echo $user['username']; ?>.jpg" id="user-img">
        <div class="overlay"></div>
    </div>
</div>
