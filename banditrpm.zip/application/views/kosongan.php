<?php 
print_r($kredit);
print_r($debit);
 ?>