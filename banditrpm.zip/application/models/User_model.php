<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model{
	public function cek_user($username,$pwd){
		$this->db->select('id_user,username,nama_user,level');
		$this->db->from('user');
		$this->db->where('user.username',$username);
		$this->db->where('user.password',$pwd);
		$result = $this->db->get();

		if ($result->num_rows() > 0) {
			return $result->result();
		}
		else
			return 0;
	}
}
